package com.groupomar.facturadigital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacturaDigitalApplication {

	public static void main(String[] args) {
		SpringApplication.run(FacturaDigitalApplication.class, args);
	}

}
