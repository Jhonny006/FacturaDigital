package com.groupomar.facturadigital;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacturaDigitalApplicationTests {

	@Test
	void contextLoads() {
	}

}
